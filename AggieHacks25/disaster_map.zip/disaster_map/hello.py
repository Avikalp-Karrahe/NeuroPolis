from preswald import sidebar, text, alert, connect, get_df, plotly, checkbox
import pandas as pd
import plotly.express as px

# Sidebar + Title
sidebar(defaultopen=True)
text("# 🌍 Disaster Risk Map (Plotly + Filters)")

# Load dataset
connect()
df = get_df("disaster_data")

if df is None or df.empty:
    alert(":x: Failed to load data", level="error")
    exit()

# Clean and classify
df = df.dropna(subset=["latitude", "longitude", "zone_id"])

df["risk_level"] = "medium"
df.loc[
    ((df["wind_speed_kmph"] > 85) | (df["precipitation_mm"] > 175)) &
    ((df["severity"] >= 8.0) | (df["casualties"] >= 85)),
    "risk_level"
] = "high"
df.loc[
    (df["wind_speed_kmph"] < 70) |
    (df["precipitation_mm"] < 120) & 
    (df["severity"] <= 6.0) & 
    (df["casualties"] <= 60),
    "risk_level"
] = "low"

# Checkbox filters
disaster_types = df["disaster_type"].unique()
risk_levels = df["risk_level"].unique()

selected_disasters = [d for d in disaster_types if checkbox(f"Include {d}", default=True)]
selected_risks = [r for r in risk_levels if checkbox(f"Include {r} risk", default=True)]

filtered_df = df[
    (df["disaster_type"].isin(selected_disasters)) &
    (df["risk_level"].isin(selected_risks))
]

# Create map
fig = px.scatter_mapbox(
    filtered_df,
    lat="latitude",
    lon="longitude",
    color="risk_level",
    color_discrete_map={"low": "green", "medium": "orange", "high": "red"},
    hover_name="disaster_type",
    hover_data={
        "zone_id": True,
        "severity": True,
        "casualties": True,
        "wind_speed_kmph": True,
        "precipitation_mm": True,
        "latitude": False,
        "longitude": False
    },
    zoom=5,
    height=650,
    title="Filtered Disaster Events"
)

fig.update_layout(mapbox_style="carto-positron", margin={"r":0,"t":40,"l":0,"b":0})
plotly(fig)
